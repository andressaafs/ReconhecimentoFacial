package reconhecimentofacial;

//São necessárias a biblioteca JavaCV e o OpenCV instalados

import org.bytedeco.javacpp.opencv_face.FaceRecognizer;
import static org.bytedeco.javacpp.opencv_face.createEigenFaceRecognizer;
import org.bytedeco.javacv.FrameGrabber;

/**
 *
 * @author Andressa & Arthur (Equipe 7)
 */
public class Teste {

    public static void main(String arg[]) throws FrameGrabber.Exception, InterruptedException {
        
        //FaceRecognizer r = createEigenFaceRecognizer();
        Captura capt = new Captura(9901946, "Andressa");
        Treinamento treinamento = new Treinamento();
        Reconhecimento reconhecimento = new Reconhecimento();
        
    }
    
}