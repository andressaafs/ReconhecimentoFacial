package reconhecimentofacial;

//São necessárias a biblioteca JavaCV e o OpenCV instalados

import java.awt.event.KeyEvent;
import java.util.Scanner;
import javax.swing.JOptionPane;
import static javax.swing.text.StyleConstants.Size;
import org.bytedeco.javacpp.opencv_core.Mat;
import org.bytedeco.javacpp.opencv_core.Rect;
import org.bytedeco.javacpp.opencv_core.RectVector;
import org.bytedeco.javacpp.opencv_core.Scalar;
import org.bytedeco.javacpp.opencv_core.Size;
import static org.bytedeco.javacpp.opencv_imgcodecs.imwrite;
import static org.bytedeco.javacpp.opencv_imgproc.COLOR_BGRA2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.rectangle;
import static org.bytedeco.javacpp.opencv_imgproc.resize;
import org.bytedeco.javacpp.opencv_objdetect.CascadeClassifier;
import org.bytedeco.javacv.CanvasFrame;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.OpenCVFrameConverter;
import org.bytedeco.javacv.OpenCVFrameGrabber;

/**
 *
 * @author Andressa & Arthur (Equipe 7)
 */
public class Captura {

    public Captura(int matricula, String nome) throws FrameGrabber.Exception, InterruptedException {

        //Cria Frames para camera com extensão pro OpenCV
        OpenCVFrameConverter.ToMat converte = new OpenCVFrameConverter.ToMat();
        OpenCVFrameGrabber camera = new OpenCVFrameGrabber(0);
        camera.start();
        KeyEvent tecla = null;
        
        //Carrega o cascade responsável pela detecção das faces
        /***
         * É possível usar os outros recursos recursos para detecção como o de banana, carro, relogios, e olhos
         * Basta configurar o CascadeClassifier e os parâmetros dos frames com os tamanhos
         */
        CascadeClassifier detectorFacial = new CascadeClassifier("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        detectorFacial.load("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        
        //Cria frame para a detecção das faces
        CanvasFrame cFrame = new CanvasFrame("Registro Funcionário", CanvasFrame.getDefaultGamma() / camera.getGamma());
        cFrame.setDefaultCloseOperation(CanvasFrame.EXIT_ON_CLOSE);
        Frame frameCapturado = null;
        Mat imgColorida = new Mat();
        
        //Para o treinamento das imagens capturaremos 25 imagens da pessoa
        int maxAmostras = 25;
        int amostra = 1;
        
        //Cadastra o funcionário no banco de dados
        /**** Obs.: O banco de dados foi retirado da apresentação para uma maior performance do código
         * O código pode ser utilizado  e modificado para utilizar CrudRepository
         */ 
        Cadastro cadastro = new Cadastro();
        int id = cadastro.registraFuncionario(matricula, nome); 
        JOptionPane.showMessageDialog(null, "Posicione-se em frente a câmera para se registrar");
        
        //Câmera está funcionando
        while ((camera.grab() = frameCapturado) != null) {
            
            //Converte imagem colorida em cinza para melhor comparação entre as imagens
            imgColorida = converte.convert(frameCapturado);
            Mat imgCinza = new Mat();
            cvtColor(imgColorida, imgCinza, COLOR_BGRA2GRAY);
            RectVector facesDetectadas = new RectVector();
            detectorFacial.detectMultiScale(imgCinza, facesDetectadas, 1.1, 1, 0, new Size(150, 150), new Size(500, 500));
            
            //Começa a capturar os frames para gravar na galeria
            for (int i = 0; i < facesDetectadas.size(); i++) {
                Rect dadosFace = facesDetectadas.get(0);
                rectangle(imgColorida, dadosFace, new Scalar(0, 0, 255, 0));
                Mat faceCapturada = new Mat(imgCinza, dadosFace);
                resize(faceCapturada, faceCapturada, new Size(160, 160));
                
                //Joga as imagens na pasta reconhecimentofacial.galeria
                if (amostra <= maxAmostras) {
                    imwrite("src\\reconhecimentofacial\\galeria\\funcionario." + id + "." + amostra + ".jpg", faceCapturada);
                    System.out.println("Foto " + amostra + " capturada\n");
                    amostra++;
                }
            }

            if (cFrame.isVisible()) {
                cFrame.showImage(frameCapturado);
            }
            
            //Delay de 200ms para tirar as fotos automaticamente sem travar
            try {
                Thread.sleep(200);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (amostra > maxAmostras) {
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
        //cFrame.dispose();
        JOptionPane.showMessageDialog(null, "Funcionário Registrado!");
        camera.stop();
    }

}
