package reconhecimentofacial;

import java.awt.event.KeyEvent;
import java.util.Scanner;
import javax.swing.JOptionPane;
import static javax.swing.text.StyleConstants.Size;
import org.bytedeco.javacpp.opencv_core.Mat;
import org.bytedeco.javacpp.opencv_core.Rect;
import org.bytedeco.javacpp.opencv_core.RectVector;
import org.bytedeco.javacpp.opencv_core.Scalar;
import org.bytedeco.javacpp.opencv_core.Size;
import static org.bytedeco.javacpp.opencv_imgcodecs.imwrite;
import static org.bytedeco.javacpp.opencv_imgproc.COLOR_BGRA2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.rectangle;
import static org.bytedeco.javacpp.opencv_imgproc.resize;
import org.bytedeco.javacpp.opencv_objdetect.CascadeClassifier;
import org.bytedeco.javacv.CanvasFrame;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.OpenCVFrameConverter;
import org.bytedeco.javacv.OpenCVFrameGrabber;

/**
 *
 * @author Andressa
 */
public class Captura {

    public Captura(int id, String nome) throws FrameGrabber.Exception, InterruptedException {

        OpenCVFrameConverter.ToMat converteMat = new OpenCVFrameConverter.ToMat();
        OpenCVFrameGrabber camera = new OpenCVFrameGrabber(0);
        camera.start();

        CascadeClassifier detectorFace = new CascadeClassifier("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        detectorFace.load("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        //detectorFace.getClass().getResource("haarcascade_frontalface_alt.xml").getPath();

        CanvasFrame cFrame = new CanvasFrame("Registro Funcionário", CanvasFrame.getDefaultGamma() / camera.getGamma());
        cFrame.setDefaultCloseOperation(CanvasFrame.EXIT_ON_CLOSE);
        Frame frameCapturado = null;
        Mat imagemColorida = new Mat();

        int maxAmostras = 25;
        int amostra = 1;

        Cadastro cadastro = new Cadastro();
        //int id = cadastro.registraFuncionario(matricula, nome);
        JOptionPane.showMessageDialog(null, "Posicione-se em frente a câmera para se registrar");

        while ((frameCapturado = camera.grab()) != null) {

            KeyEvent tecla = null;

            imagemColorida = converteMat.convert(frameCapturado);
            Mat imagemCinza = new Mat();
            cvtColor(imagemColorida, imagemCinza, COLOR_BGRA2GRAY);
            RectVector facesDetectadas = new RectVector();
            detectorFace.detectMultiScale(imagemCinza, facesDetectadas, 1.1, 1, 0, new Size(150, 150), new Size(500, 500));

            for (int i = 0; i < facesDetectadas.size(); i++) {
                Rect dadosFace = facesDetectadas.get(0);
                rectangle(imagemColorida, dadosFace, new Scalar(0, 0, 255, 0));
                Mat faceCapturada = new Mat(imagemCinza, dadosFace);
                resize(faceCapturada, faceCapturada, new Size(160, 160));

                /*try {
                    Thread.sleep(5000);
                } catch (Exception e) {
                    e.printStackTrace();
                }*/

                
                if (amostra <= maxAmostras) {
                    imwrite("src\\reconhecimentofacial\\galeria\\funcionario." + id + "." + amostra + ".jpg", faceCapturada);
                    System.out.println("Foto " + amostra + " capturada\n");
                    amostra++;
                }
            }

            if (cFrame.isVisible()) {
                cFrame.showImage(frameCapturado);
            }

            try {
                Thread.sleep(200);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (amostra > maxAmostras) {
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
        //cFrame.dispose();
        JOptionPane.showMessageDialog(null, "Funcionário Registrado!");
        camera.stop();
    }

}
