package reconhecimentofacial;

import java.util.ArrayList;
import java.util.List;

public class Cadastro {

    private List<Funcionario> funcionarios = new ArrayList<Funcionario>();
    
    public Cadastro () {
        /*Funcionario f1 = 
        funcionarios.add(0, )*/
    }

    public Integer registraFuncionario(String nome) {
        int id = geraId();
        Funcionario func = new Funcionario(id, nome);
        funcionarios.add(id, func);
        return id;
    }

    public int geraId() {
        int ultimo = funcionarios.size();
        return ultimo;
    }

    public boolean verificaFuncionario(String matricula) {
        return true;
    }

    public List<String> listaFuncionarios() {
        List<String> nomes = new ArrayList<String>();
        for (int i = 0; i < funcionarios.size(); i++) {
            Funcionario func = funcionarios.get(i);
            nomes.add(func.getNome());
        }
        return nomes;
    }
}
