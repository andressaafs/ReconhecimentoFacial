package reconhecimentofacial;

public class Funcionario {
    
    private int id;
   // private String matricula;
    private String nome;
    
    public Funcionario (int id, String nome) {
        this.id = id;
        //this.matricula = matricula;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /*public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }*/

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
}
