package reconhecimentofacial;

//São necessárias a biblioteca JavaCV e o OpenCV instalados

import java.util.ArrayList;
import java.util.List;
import org.bytedeco.javacpp.DoublePointer;
import org.bytedeco.javacpp.IntPointer;
import static org.bytedeco.javacpp.opencv_core.FONT_HERSHEY_PLAIN;
import org.bytedeco.javacpp.opencv_core.Mat;
import org.bytedeco.javacpp.opencv_core.Point;
import org.bytedeco.javacpp.opencv_core.Rect;
import org.bytedeco.javacpp.opencv_core.RectVector;
import org.bytedeco.javacpp.opencv_core.Scalar;
import org.bytedeco.javacpp.opencv_core.Size;
import org.bytedeco.javacpp.opencv_face.FaceRecognizer;
import static org.bytedeco.javacpp.opencv_face.createEigenFaceRecognizer;
import static org.bytedeco.javacpp.opencv_face.createFisherFaceRecognizer;
import static org.bytedeco.javacpp.opencv_face.createLBPHFaceRecognizer;
import static org.bytedeco.javacpp.opencv_imgproc.COLOR_BGRA2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.cvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.putText;
import static org.bytedeco.javacpp.opencv_imgproc.rectangle;
import static org.bytedeco.javacpp.opencv_imgproc.resize;
import org.bytedeco.javacpp.opencv_objdetect.CascadeClassifier;
import org.bytedeco.javacv.CanvasFrame;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.OpenCVFrameConverter;
import org.bytedeco.javacv.OpenCVFrameGrabber;

/**
 *
 * @author Andressa & Arthur (Equipe 7)
 */
public class Reconhecimento {

    public Reconhecimento() throws FrameGrabber.Exception {
         
        //Colete os funcionários já registrados para usar os seus IDs e comparar com o que foi salvo na galeria
        Cadastro cadastro = new Cadastro();
        List<String> pessoas = new ArrayList<String>();
        pessoas = cadastro.listaFuncionarios();
        
        //Cria Frames para camera com extensão pro OpenCV
        OpenCVFrameConverter.ToMat converte = new OpenCVFrameConverter.ToMat();
        OpenCVFrameGrabber camera = new OpenCVFrameGrabber(0);
        camera.start();

        //Carrega o cascade responsável por detecção das faces
        CascadeClassifier detectorFacial = new CascadeClassifier("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        detectorFacial.load("src\\reconhecimentofacial\\recursos\\haarcascade_frontalface_alt.xml");
        
        // Para executar cada algoritmo de detecção é necessário somente ocultar os outros algoritmos  
        
        // Eigen Face
        //FaceRecognizer reconhecedor = createEigenFaceRecognizer();
        //reconhecedor.load("src\\reconhecimentofacial\\recursos\\classificadorEigenFaces.yml");
        //reconhecedor.setThreshold(0);
        
        // Fisher Face
        //FaceRecognizer reconhecedor = createFisherFaceRecognizer();
        //reconhecedor.load("src\\reconhecimentofacial\\recursos\\classificadorFisherFaces.yml");
        
        // LBPH Face
        FaceRecognizer reconhecedor = createLBPHFaceRecognizer();
        reconhecedor.load("src\\reconhecimentofacial\\recursos\\classificadorLBPH.yml");
        
        //Cria frame para a detecção das faces
        CanvasFrame cFrame = new CanvasFrame("Reconhecimento", CanvasFrame.getDefaultGamma() / camera.getGamma());
        cFrame.setDefaultCloseOperation(CanvasFrame.EXIT_ON_CLOSE);
        Frame frameCapturado = null;
        Mat imgColorida = new Mat();

        while ((frameCapturado = camera.grab()) != null) {
          //Câmera está funcionando
        while ((camera.grab() = frameCapturado) != null) {
            
            //Converte imagem colorida em cinza para melhor comparação entre as imagens
            imgColorida = converte.convert(frameCapturado);
            Mat imgCinza = new Mat();
            cvtColor(imgColorida, imgCinza, COLOR_BGRA2GRAY);
            RectVector facesDetectadas = new RectVector();
            detectorFacial.detectMultiScale(imgCinza, facesDetectadas, 1.1, 1, 0, new Size(150, 150), new Size(500, 500));
            
            //Começa a capturar os frames para gravar na galeria
            for (int i = 0; i < facesDetectadas.size(); i++) {
                Rect dadosFace = facesDetectadas.get(0);
                rectangle(imgColorida, dadosFace, new Scalar(0, 0, 255, 0));
                Mat faceCapturada = new Mat(imgCinza, dadosFace);
                resize(faceCapturada, faceCapturada, new Size(160, 160));
                
                //Pega os rotulos pertencentes a cada imagem gerada no Treinamento
                IntPointer rotulo = new IntPointer(1);
                DoublePointer confianca = new DoublePointer(1);
                reconhecedor.predict(faceCapturada, rotulo, confianca);
                
                /***
                 * Se o rótulo corresponde a algum funcionário presente nos classificadores, 
                 * ele retorna o nome com os parâmetros de confiança
                 * Confiança é a distância (de proximidade) entre a imagem média correspondente ao funcionário
                 * Imagem média é uma imagem matriz gerada pelo algoritmo de reconhecimento, que é o padrão da face do funcionário
                 * Cada algoritmo tem uma forma de gerar a imagem média, que é gerada a partir das 25 amostrar tiradas na Captura
                 */
                int predicao = rotulo.get(0);
                String nome;
                if (predicao == -1) {
                    nome = "Desconhecido";
                } else {
                    nome = pessoas.get(predicao) + " - " + confianca.get(0);
                }

                int x = Math.max(dadosFace.tl().x() - 10, 0);
                int y = Math.max(dadosFace.tl().y() - 10, 0);
                putText(imagemColorida, nome, new Point(x, y), FONT_HERSHEY_PLAIN, 1.4, new Scalar(0, 255, 0, 0));
            }
            
            if (cFrame.isVisible()) {
                cFrame.showImage(frameCapturado);
            }
        }
        
        cFrame.dispose();
        camera.stop();
    }
}
